/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.caso_programado2javierretanagarcia;

/**
 *
 * @author jareg
 */
public class Caso_Programado2JavierRetanaGarcia {

    public static void main(String[] args) {
       
    }
}
    
