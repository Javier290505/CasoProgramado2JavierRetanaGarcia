/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.caso_programado2javierretanagarcia;

import java.util.ArrayList;

/**
 *
 * @author jareg
 */
public class Hotel {

    private final ArrayList<Habitaciones> Habitaciones = new ArrayList<>();

    public Hotel() {
        cargarHabitaciones();
    }

    private void cargarHabitaciones() {

        /////Piso3
        Habitaciones.add(new Habitaciones(301, "Doble", 50.0, "Sucia"));
        Habitaciones.add(new Habitaciones(302, "Simple", 60.0, "Libre"));
        Habitaciones.add(new Habitaciones(303, "Simple", 40.0, "Libre"));
        Habitaciones.add(new Habitaciones(304, "Doble", 30.0, "Libre"));
        Habitaciones.add(new Habitaciones(305, "Simple", 40.0, "Sucia"));

        ////Piso2
        Habitaciones.add(new Habitaciones(201, "Simple", 40.0, "Libre"));
        Habitaciones.add(new Habitaciones(202, "Doble", 30.0, "Libre"));
        Habitaciones.add(new Habitaciones(203, "Simple", 60.0, "Libre"));
        Habitaciones.add(new Habitaciones(204, "Doble", 30.0, "Libre"));
        Habitaciones.add(new Habitaciones(205, "Simple", 50.0, "Sucia"));

        ////Piso1
        Habitaciones.add(new Habitaciones(101, "Simple", 40.0, "Sucia"));
        Habitaciones.add(new Habitaciones(102, "Doble", 30.0, "Libre"));
        Habitaciones.add(new Habitaciones(103, "Simple", 60.0, "Sucia"));
        Habitaciones.add(new Habitaciones(104, "Doble", 30.0, "Libre"));
        Habitaciones.add(new Habitaciones(105, "Simple", 40.0, "Sucia"));

    }

    public void mostrarHabitaciones() {
        System.out.println("\n  Estado de las Habitaciones ");
        for (Habitaciones h : Habitaciones) {
            h.mostrarInformacion();
        }
    }


}
