/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.caso_programado2javierretanagarcia;

/**
 *
 * @author jareg
 */
public class Habitaciones {
    
    int numero;
    String tipo;
    double PrecioPorNoche;
    private String Estado;
    String estado;

    public Habitaciones(int numero, String tipo, double PrecioPorNoche, String Estado) {
        this.numero = numero;
        this.tipo = tipo;
        this.PrecioPorNoche = PrecioPorNoche;
        this.Estado = Estado;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public void setPrecioPorNoche(double PrecioPorNoche) {
        this.PrecioPorNoche = PrecioPorNoche;
    }

    public void setEstado(String Estado) {
        this.Estado = Estado;
    }

    public int getNumero() {
        return numero;
    }

    public String getTipo() {
        return tipo;
    }

    public double getPrecioPorNoche() {
        return PrecioPorNoche;
    }

    public String getEstado() {
        return Estado;
    }
  
    public void mostrarinformacion(){
        System.out.println(Estado + "Habitacion" + numero + " | Tipo" + tipo + "| Precio" + PrecioPorNoche + " | Estado");
    }

    void mostrarInformacion() {
        
    }
    
}
